import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';

export default function Home(){
  return(
    
    <View style={style.container}> 
    <View style={style.header}> 
        <Text style={style.titulo}>Pizzaria</Text></View>

    <ScrollView>

<View style={style.linhas}>

    <View style={style.cards}> 
    <Image style={style.heinek} resizeMode="contain" source={require("../assets/mussarela.png")} />
    <Text style={style.t}> 
    Fatia Pizza de Mussarela
    </Text>
    <Text style={style.preco}> R$ 6,39</Text>
    </View>

    <View style={style.cards}>
    <Image style={style.itaipava} resizeMode="contain" source={require("../assets/calabresa.png")} /> 
        <Text style={style.t}> 
    Fatia Pizza de Calabresa
    </Text> 
    <Text style={style.preco}> R$ 7,50 </Text>
    </View>

</View>



<View style={style.linhas}>

    <View style={style.cards}> 
    <Image style={style.coquine} resizeMode="contain" source={require("../assets/peperoni.png")} />
    <Text style={style.t}> 
     Fatia Pizza Peperoni
    </Text>
    <Text style={style.preco}> R$ 7,99</Text>
    </View>

 

</View>
    <View style={style.cards}>
    <Text>Ah Degah - João Pedro | Nathan Souza 2k23</Text>
  </View>
    </ScrollView>
   </View>
  )
}
  const style = StyleSheet.create({
      container: {
      flex: 1,
      display: 'flex',
      backgroundColor: '#fffff',
      justifyContent: 'center',
      alignItems: 'center'
    },
      t: {
        display: 'flex',
        textAlign: 'left',
        color: '#000',
        fontSize: 17,
        justifyContent: 'center',
        alignItems: 'center',
        margin: 10
      },
      linhas: {
        flexDirection: 'row', 
        justifyContent: 'space-around',
        alignItems: 'center',
        borderColor: '#000000',
        border: 5
      },
      header: {
        width: '100%',
        height: 80,
        display: 'flex 1',
        justifyContent: 'center',
        backgroundColor: '#363636'
      },
      titulo: {
        textAlign: 'center',
        marginTop: 25,
        fontSize: 25,
        fontWeight: 'bold',
        color: 'whitesmoke'
      },
      itaipava: {
        width: 250,
        height: 130,
        marginTop: 50
      },
      heinek: {
        width: 250,
        height: 150,
        marginTop: 30
      },
      coquine: {
        width: 250,
        height: 150,
        marginTop: 30
      },
      cards: {
        flex: 1,
        width: 300,
        height: 300,
        justifyContent: 'center',
        alignItems: 'center',
        margin: 20,
        backgroundColor: '#fffff',
        borderRadius: '50%',
        padding: 5
      },
      preco: {
        fontWeight: 'bold',
        fontSize: 19
      },
   });





