import {useState,useEffect} from 'react';

import {
Text,
SafeAreaView, 
StyleSheet,
Image,
View,
TextInput,
TouchableOpacity 
} from 'react-native';

import Firebase from '../firebase';



export default function Login({navigation}) {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [user, setUser] = useState('');


  function login(){
    Firebase.auth().signInWithEmailAndPassword(email,senha).catch(function (error)
    {
      var errorCode = error.code;
      var errorMessage = error.message;
      alert(errorCode,errorMessage);

    })
  }
  useEffect(()=>{
    Firebase.auth().onAuthStateChanged(function(user){
      setUser(user)
      if(initializing) setInitializing(false)
    });
  },[])

  if(user){
    alert('Bem-Vindo'+ user.uid);
    return navigation.navigate('Home');
  }
  else{
   
  }

  return (

    <SafeAreaView style={styles.tudao}>

    <View style={styles.viewtitulo}>   
         <Image resizeMode="contain" style={styles.imgdomino} source={require("../assets/domino.png")}></Image> 
    </View>
    <SafeAreaView style={styles.sview}>
      <Text style={styles.txtazul}> Usuário</Text>
      <TextInput style={styles.inputs}  
      placeholder="email de acesso"
      onChangeText={(email) => setEmail(email)}
      value={email}
      />
      <Text style={styles.txtazul}> Senha</Text>
      <TextInput style={styles.inputs}
      placeholder="senha"
      onChangeText={(senha) => setSenha(senha)}
      value={senha}
      />

      <View style={styles.viewbtn}>
      <TouchableOpacity style={styles.btn} 
      onPress={() => {
        login();
      }}
      >
      <Text style={styles.btntexto}> Login </Text>
      </TouchableOpacity>
      </View>

    </SafeAreaView>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  tudao: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  sview: {
    backgroundColor: '#e4f2f7',
    borderWidth: 2,
    borderRadius: 14,
    width: 300,
    padding: 30,
  },
  viewtitulo: {
    backgroundColor: '#fffff',
    padding: 50
  },
  inputs: {
    margin: 20,
    borderBottomWidth: 1,
    padding: 20,
    borderRadius:10,
    fontSize: 24,
    height: 104,
    width: 'auto'
  },
  imgdomino:{
    width: 200,
    height: 100,
  },
  btn:{
    backgroundColor: '#53666c',
    width: 220,
    height: 80,
    borderRadius: 50,
    marginTop: 70,
    justifyContent: 'center'
  },
  btntexto: {
    alignItems: 'center',
    color: 'whitesmoke',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 20,
  },
  viewbtn: {
    height:2,
    alignItems: 'center',
    marginBottom: 6,
  },
  txtazul:{
    fontWeight: 'bold',
    padding: 10
  }
});