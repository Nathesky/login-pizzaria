import { initializeApp } from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyDX-tRk8bHmUQpqNtyhqyNIWfX-KtkJZ2k",
  authDomain: "database-pizzaria.firebaseapp.com",
  projectId: "database-pizzaria",
  storageBucket: "database-pizzaria.appspot.com",
  messagingSenderId: "895593013954",
  appId: "1:895593013954:web:e57b8968696d650a5fd15b"
};


const app = initializeApp(firebaseConfig);

export default app